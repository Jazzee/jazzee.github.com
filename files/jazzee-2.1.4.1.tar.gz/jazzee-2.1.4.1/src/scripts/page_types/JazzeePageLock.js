/**
 * The JazzeePageLock type
  @extends JazzeePage
 */
function JazzeePageLock(){}
JazzeePageLock.prototype = new JazzeePage();
JazzeePageLock.prototype.constructor = JazzeePageLock;