/**
 * Javascript for the manage_cycles controller
 */
$(document).ready(function(){
  $('div.form input.DateInput').datepicker({
    showOn: "button",
    buttonImage: "resource/foundation/media/icons/calendar_edit.png",
    buttonImageOnly: true
  });
});