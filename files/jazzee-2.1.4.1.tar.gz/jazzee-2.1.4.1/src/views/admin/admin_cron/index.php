<?php
/**
 * Admin cron view
 * outputs nothing
 */