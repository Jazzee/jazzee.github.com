<?php
/**
 * lor missed deadline view
 * 
 */
?>
<p>The deadline for completing this recommendation was <?php print $deadline; ?></p>