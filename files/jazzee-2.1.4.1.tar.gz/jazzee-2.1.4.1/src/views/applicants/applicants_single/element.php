<?php

/**
 * render a dymanic element
 */
$this->renderElement($element, $variables);