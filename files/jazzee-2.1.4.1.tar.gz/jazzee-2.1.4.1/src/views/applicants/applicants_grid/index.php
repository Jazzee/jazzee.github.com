<?php

/**
 * applicants_grid index view
 * @author Jon Johnson <jon.johnson@ucsf.edu>
 * @license http://jazzee.org/license.txt
 * @package jazzee
 * @subpackage admin
 */
?>
<noscript>This Page Requires javascript.  Please consult your department IT support for help enabling Javascript in your browser.</noscript>
<div id='ajaxstatus'></div>

<div id="grid"></div>