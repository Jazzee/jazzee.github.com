<?php
/**
 * apply_account generic form
 * @package jazzee
 * @subpackage apply
 */
$this->renderElement('form', array('form' => $form));