<?php
/**
 * appicant_resetpassword view
 */
$this->renderElement('form', array('form' => $form));