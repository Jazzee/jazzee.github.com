<?php
/**
 * appicant_login view
 */
$this->renderElement('form', array('form' => $form));