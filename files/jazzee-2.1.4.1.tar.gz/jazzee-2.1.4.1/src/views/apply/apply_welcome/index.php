<?php
/**
 * Display program welcome message
 * 
 */
?>
<p><?php echo $application->getWelcome() ?></p>