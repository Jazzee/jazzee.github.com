<?php

/**
 * manage_elementtypes edit view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}