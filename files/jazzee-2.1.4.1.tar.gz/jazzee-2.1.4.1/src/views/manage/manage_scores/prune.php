<?php
/**
 * manage_scores prune view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}