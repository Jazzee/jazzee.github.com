<?php

/**
 * manage_roles copy view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}