<?php

/**
 * manage_cycles edit view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}