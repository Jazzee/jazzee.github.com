<?php

/**
 * manage_programs edit view
 * 
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}