<?php

/*
 * Transaction controller view
 * outputs nothing
 */