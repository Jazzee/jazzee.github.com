<?php

/**
 * setup_tags edit form
 */
$this->renderElement('form', array('form' => $form));