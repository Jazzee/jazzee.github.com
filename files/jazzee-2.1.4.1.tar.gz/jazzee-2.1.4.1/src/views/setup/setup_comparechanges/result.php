<?php
/**
 * setup_comparechanges result view
 *
 */
?>"result":<?php print json_encode($result);