<?php

/**
 * setup_copyapplication view
 * 
 */
$this->renderElement('form', array('form' => $form));