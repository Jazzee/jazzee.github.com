<?php
/**
 * setup_pages result view
 *
 */
?>"result":<?php print json_encode($result);