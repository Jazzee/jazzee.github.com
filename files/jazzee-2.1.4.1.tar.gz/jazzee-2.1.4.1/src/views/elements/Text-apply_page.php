<?php
/**
 * apply_page Text page types view
 */
?>
<div id='leadingText'><?php print $page->getLeadingText() ?></div>
<div id='trailingText'><?php print $page->getTrailingText() ?></div>