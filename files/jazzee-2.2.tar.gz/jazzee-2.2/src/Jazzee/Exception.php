<?php
namespace Jazzee;

/**
 * Exception Class for Jazzee
 *
 * @author  Jon Johnson  <jon.johnson@ucsf.edu>
 * @license http://jazzee.org/license BSD-3-Clause
 */
class Exception extends \Foundation\Exception
{

}
