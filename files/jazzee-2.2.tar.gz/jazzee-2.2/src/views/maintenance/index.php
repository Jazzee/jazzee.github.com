<?php
/**
 * Maintenance Mode view
 */
?>
<p><?php echo $message ?></p>

