<?php
/**
 * applicant_new view
 */
$this->renderElement('form', array('form' => $form));