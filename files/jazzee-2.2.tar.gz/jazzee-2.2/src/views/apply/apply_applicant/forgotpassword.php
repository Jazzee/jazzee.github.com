<?php
/**
 * appicant_forgotpassword view
 */
$this->renderElement('form', array('form' => $form));