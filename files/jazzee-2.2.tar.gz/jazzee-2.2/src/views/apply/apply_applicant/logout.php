<?php
/**
 * applicant_logout view
 */
?>
<p>You have been logged out successfully.  Thank you.</p>