<?php
/**
 * Admin logout view
 */
?>
<p>You have been logged out successfully.</p>
<p><a href='<?php print $this->path('welcome'); ?>'>Return to the application</a>.