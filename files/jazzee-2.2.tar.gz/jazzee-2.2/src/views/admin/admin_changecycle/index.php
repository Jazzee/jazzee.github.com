<?php

/**
 * admin_changecycle view
 * @author Jon Johnson <jon.johnson@ucsf.edu>
 * @license http://jazzee.org/license.txt
 * @package jazzee
 * @subpackage admin
 */
$this->renderElement('form', array('form' => $form));