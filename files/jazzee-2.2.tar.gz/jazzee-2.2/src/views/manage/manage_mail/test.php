<?php
/**
 * manage_mail test view
 * 
 */
$this->renderElement('form', array('form'=>$form));
