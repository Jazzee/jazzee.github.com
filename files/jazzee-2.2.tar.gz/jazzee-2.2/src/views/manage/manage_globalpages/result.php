<?php
/**
 * manage_globalpages result view
 * a default json view for outputting simple data
 * @author Jon Johnson <jon.johnson@ucsf.edu>
 * @package jazzee
 * @subpackage admin
 * @subpackage setup
 */
?>"result":<?php print json_encode($result);