<?php

/**
 * manage_pagetypes edit view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}