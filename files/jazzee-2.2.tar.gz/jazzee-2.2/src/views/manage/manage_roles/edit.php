<?php

/**
 * manage_roles edit view
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}