<?php

/**
 * manage_programs new view
 * 
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}