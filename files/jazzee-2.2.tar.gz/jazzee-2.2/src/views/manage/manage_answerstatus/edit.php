<?php

/**
 * manage_virtualfiles edit view
 * 
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}