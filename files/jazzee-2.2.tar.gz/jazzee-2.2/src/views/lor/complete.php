<?php
/**
 * lor complete view
 * Shows only the message that the recommendation has already been submitted
 * 
 */
?>
<p>This recommendation has already been completed.</p>