<?php

/**
 * set_decisionletters editAdmitLetter
 *
 */
if (isset($form)) {
  $this->renderElement('form', array('form' => $form));
}