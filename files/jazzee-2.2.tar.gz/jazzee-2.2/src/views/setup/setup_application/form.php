<?php

/**
 * setup_application generic form
 */
$this->renderElement('form', array('form' => $form));