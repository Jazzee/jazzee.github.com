<?php

/**
 * applicants_decisions generic form
 * @package jazzee
 * @subpackage admin
 * @subpackage applicants
 */
$this->renderElement('form', array('form' => $form));