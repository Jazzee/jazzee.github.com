<?php
/**
 *  result view
 *
 */
if(isset($result)){?>"result":<?php print json_encode($result); } ?>