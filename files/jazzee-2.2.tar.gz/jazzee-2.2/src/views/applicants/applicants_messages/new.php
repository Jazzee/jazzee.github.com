<?php

/**
 * applicants_messages new view
 */
$this->renderElement('form', array('form' => $form));